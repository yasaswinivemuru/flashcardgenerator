// ========== Typing effect ==========
function typeEffect(el, text, speed=60) {
  el.innerHTML = "";
  let i = 0;
  (function typing() {
    if (i < text.length) {
      el.innerHTML += text.charAt(i++);
      setTimeout(typing, speed);
    }
  })();
}

// Title typing
window.addEventListener('load', () => {
  typeEffect(document.getElementById('title'), 'Flashcard Generator', 70);
  setTimeout(() => typeEffect(document.getElementById('subtitle'), 'Clarity. Focus. Impact.', 50), 1200);
});

// ========== Flashcards ==========
function createCard(term, def) {
  const card = document.createElement('div');
  card.className = 'card';

  const inner = document.createElement('div');
  inner.className = 'card-inner';

  const front = document.createElement('div');
  front.className = 'card-front';
  typeEffect(front, term, 35);

  const back = document.createElement('div');
  back.className = 'card-back';
  typeEffect(back, def, 35);

  inner.appendChild(front);
  inner.appendChild(back);
  card.appendChild(inner);

  const del = document.createElement('button');
  del.className = 'delete-btn';
  del.textContent = '✖';
  del.addEventListener('click', (e) => { e.stopPropagation(); card.remove(); });
  card.appendChild(del);

  card.addEventListener('click', () => card.classList.toggle('flipped'));

  document.getElementById('cards').appendChild(card);
}

// Add single
document.getElementById('addBtn').onclick = async () => {
  const term = document.getElementById('term').value.trim();
  const def = document.getElementById('definition').value.trim();
  if (!term || !def) return;
  // optional: persist to backend simple store
  await fetch('/api/flashcards', {
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({term, definition:def})
  }).catch(()=>{});
  createCard(term, def);
  document.getElementById('term').value=''; document.getElementById('definition').value='';
};

// Bulk
document.getElementById('generateBtn').onclick = () => {
  const lines = document.getElementById('bulkInput').value.split('\n');
  lines.forEach(line => {
    const parts = line.split('-');
    if (parts.length >= 2) {
      const term = parts[0].trim();
      const def = parts.slice(1).join('-').trim();
      if (term && def) createCard(term, def);
    }
  });
};

// AI by topic (GET /api/ai/generate?topic=...)
document.getElementById('aiBtn').onclick = async () => {
  const topic = document.getElementById('bulkInput').value.trim();
  if (!topic) { alert('Enter a topic in the textarea first.'); return; }
  const res = await fetch('/api/ai/generate?topic=' + encodeURIComponent(topic));
  if (!res.ok) { alert('AI generation failed'); return; }
  const data = await res.json();
  data.forEach(item => createCard(item.term, item.definition));
};

// ========== Particles ==========
const particleCanvas = document.getElementById('particleCanvas');
const ctx = particleCanvas.getContext('2d');
function resizeCanvas(){
  particleCanvas.width = window.innerWidth;
  particleCanvas.height = window.innerHeight;
}
resizeCanvas(); window.addEventListener('resize', resizeCanvas);

const particles = Array.from({length: 90}).map(()=> ({
  x: Math.random()*particleCanvas.width,
  y: Math.random()*particleCanvas.height,
  dx: (Math.random()-0.5)*1.5,
  dy: (Math.random()-0.5)*1.5,
  size: Math.random()*2+0.5
}));

function drawParticles(){
  ctx.clearRect(0,0,particleCanvas.width,particleCanvas.height);
  ctx.fillStyle = 'rgba(255,255,255,0.8)';
  particles.forEach(p=>{
    ctx.beginPath(); ctx.arc(p.x,p.y,p.size,0,Math.PI*2); ctx.fill();
    p.x+=p.dx; p.y+=p.dy;
    if(p.x<0||p.x>particleCanvas.width) p.dx*=-1;
    if(p.y<0||p.y>particleCanvas.height) p.dy*=-1;
  });
  requestAnimationFrame(drawParticles);
}
drawParticles();

// ========== Three.js Cube ==========
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 1000);
const renderer = new THREE.WebGLRenderer({ canvas: document.getElementById('threeCanvas'), alpha: true });
renderer.setSize(window.innerWidth, window.innerHeight);
const geom = new THREE.BoxGeometry(1.6,1.6,1.6);
const mat = new THREE.MeshStandardMaterial({ color: 0x7873f5, metalness: 0.6, roughness: 0.3 });
const cube = new THREE.Mesh(geom, mat); scene.add(cube);
const light = new THREE.PointLight(0xffffff, 1); light.position.set(5,5,5); scene.add(light);
camera.position.z = 5;
function animate(){ requestAnimationFrame(animate); cube.rotation.x+=0.01; cube.rotation.y+=0.01; renderer.render(scene,camera); }
animate();
window.addEventListener('resize', ()=>{
  camera.aspect = window.innerWidth/window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});

// ========== Optional Rive small loops (if you place assets) ==========
try{
  new rive.Rive({ src: 'assets/rive-star.riv',  canvas: document.getElementById('riveCorner1'), autoplay: true });
  new rive.Rive({ src: 'assets/rive-heart.riv', canvas: document.getElementById('riveCorner2'), autoplay: true });
  new rive.Rive({ src: 'assets/rive-bubble.riv',canvas: document.getElementById('riveFree1'),  autoplay: true });
  new rive.Rive({ src: 'assets/rive-shape.riv', canvas: document.getElementById('riveFree2'),  autoplay: true });
}catch(e){ /* ignore if assets missing */ }
