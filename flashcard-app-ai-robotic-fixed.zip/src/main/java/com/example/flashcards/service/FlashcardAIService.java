package com.example.flashcards.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;

@Service
public class FlashcardAIService {

    @Value("${openai.api.key:}")
    private String apiKey;

    private static final String OPENAI_URL = "https://api.openai.com/v1/chat/completions";
    private final ObjectMapper mapper = new ObjectMapper();

    public List<Map<String, String>> generate(String topic) {
        if (apiKey == null || apiKey.isBlank()) {
            // Fallback mock if key is missing
            return List.of(
                    Map.of("term", topic + " – Overview", "definition", "High-level summary about " + topic),
                    Map.of("term", topic + " – Key Concept", "definition", "Important idea related to " + topic),
                    Map.of("term", topic + " – Example", "definition", "A quick example for " + topic),
                    Map.of("term", topic + " – Pitfall", "definition", "A common mistake about " + topic),
                    Map.of("term", topic + " – Tip", "definition", "A useful tip for " + topic)
            );
        }

        RestTemplate rest = new RestTemplate();
        String prompt = "Generate exactly 5 flashcards about '" + topic + "'. " +
        "Respond ONLY with a valid JSON array. " +
        "Each element must have two fields: 'term' and 'definition'.";

        Map<String, Object> body = new HashMap<>();
        body.put("model", "gpt-4o-mini");
        body.put("messages", List.of(Map.of("role", "user", "content", prompt)));
        body.put("max_tokens", 600);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(apiKey);

        HttpEntity<Map<String,Object>> entity = new HttpEntity<>(body, headers);

        try {
            ResponseEntity<Map> resp = rest.exchange(OPENAI_URL, HttpMethod.POST, entity, Map.class);
            Object choices = resp.getBody().get("choices");
            if (!(choices instanceof List) || ((List<?>) choices).isEmpty()) {
                throw new RuntimeException("No choices from OpenAI");
            }
            Object message = ((Map)((List)choices).get(0)).get("message");
            String content = String.valueOf(((Map)message).get("content"));

            // Strip code fences if present
            content = content.trim();
            if (content.startsWith("```")) {
                int first = content.indexOf('
');
                int last = content.lastIndexOf("```");
                if (first >= 0 && last > first) {
                    content = content.substring(first+1, last).trim();
                }
            }
            // Parse JSON array
            List<Map<String,String>> parsed = mapper.readValue(content, List.class);
            return parsed;
        } catch (Exception e) {
            return List.of(
                Map.of("term","Error","definition","OpenAI call failed: " + e.getMessage())
            );
        }
    }
}
