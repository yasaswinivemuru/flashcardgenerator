package com.example.flashcards.service;

import com.example.flashcards.Flashcard;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class FlashcardService {
    private final List<Flashcard> cards = new ArrayList<>();

    public List<Flashcard> getAll() {
        return cards;
    }

    public Flashcard add(Flashcard card) {
        cards.add(card);
        return card;
    }
}
