package com.example.flashcards;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlashcardAppApplication {
    public static void main(String[] args) {
        SpringApplication.run(FlashcardAppApplication.class, args);
    }
}
