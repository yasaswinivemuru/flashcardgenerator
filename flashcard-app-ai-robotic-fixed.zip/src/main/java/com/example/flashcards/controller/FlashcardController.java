package com.example.flashcards.controller;

import com.example.flashcards.Flashcard;
import com.example.flashcards.service.FlashcardService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/flashcards")
@CrossOrigin
public class FlashcardController {
    private final FlashcardService service;
    public FlashcardController(FlashcardService service) { this.service = service; }

    @GetMapping
    public List<Flashcard> all() { return service.getAll(); }

    @PostMapping
    public Flashcard add(@RequestBody Flashcard card) { return service.add(card); }
}
