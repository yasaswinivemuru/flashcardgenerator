package com.example.flashcards.controller;

import com.example.flashcards.service.FlashcardAIService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/ai")
@CrossOrigin
public class FlashcardAIController {

    private final FlashcardAIService aiService;

    public FlashcardAIController(FlashcardAIService aiService) {
        this.aiService = aiService;
    }

    @GetMapping("/generate")
    public List<Map<String,String>> generate(@RequestParam String topic){
        return aiService.generate(topic);
    }
}
